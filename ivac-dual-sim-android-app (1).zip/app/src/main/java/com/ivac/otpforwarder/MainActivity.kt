package com.ivac.otpforwarder

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var etSim1Phone: EditText
    private lateinit var etSim2Phone: EditText
    private lateinit var tvSim1Status: TextView
    private lateinit var tvSim2Status: TextView
    private lateinit var tvServiceStatus: TextView
    private lateinit var btnSave: Button
    private lateinit var btnRequestBattery: Button

    companion object {
        private const val PERMISSION_REQ_CODE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("ivac_otp_prefs", Context.MODE_PRIVATE)

        etSim1Phone = findViewById(R.id.etSim1Phone)
        etSim2Phone = findViewById(R.id.etSim2Phone)
        tvSim1Status = findViewById(R.id.tvSim1Status)
        tvSim2Status = findViewById(R.id.tvSim2Status)
        tvServiceStatus = findViewById(R.id.tvServiceStatus)
        btnSave = findViewById(R.id.btnSave)
        btnRequestBattery = findViewById(R.id.btnRequestBattery)

        etSim1Phone.setText(prefs.getString("sim1_number", ""))
        etSim2Phone.setText(prefs.getString("sim2_number", ""))

        btnSave.setOnClickListener {
            val s1 = etSim1Phone.text.toString().trim()
            val s2 = etSim2Phone.text.toString().trim()

            prefs.edit()
                .putString("sim1_number", s1)
                .putString("sim2_number", s2)
                .apply()

            Toast.makeText(this, "সিম নম্বর সফলভাবে সংরক্ষণ করা হয়েছে!", Toast.LENGTH_SHORT).show()
        }

        btnRequestBattery.setOnClickListener {
            requestIgnoreBatteryOptimization()
        }

        checkAndRequestPermissions()
        detectSimSlots()
        startForwarderService()
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val ungranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (ungranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, ungranted.toTypedArray(), PERMISSION_REQ_CODE)
        }
    }

    private fun detectSimSlots() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        try {
            val subManager = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            val subList: List<SubscriptionInfo>? = subManager.activeSubscriptionInfoList

            if (!subList.isNullOrEmpty()) {
                for (info in subList) {
                    val slot = info.simSlotIndex + 1
                    val carrier = info.carrierName ?: "Carrier"
                    if (slot == 1) {
                        tvSim1Status.text = "📶 সিম ১ সক্রিয় ($carrier)"
                    } else if (slot == 2) {
                        tvSim2Status.text = "📶 সিম ২ সক্রিয় ($carrier)"
                    }
                }
            }
        } catch (e: SecurityException) {
            // handle
        }
    }

    private fun requestIgnoreBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "ব্যাটারি অপ্টিমাইজেশন ইতিমধ্যে বন্ধ রয়েছে (Unrestricted)!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startForwarderService() {
        val serviceIntent = Intent(this, OtpForwarderService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        tvServiceStatus.text = "সার্ভিস স্ট্যাটাস: সার্বক্ষণিক সক্রিয় (Active)"
    }
}
